package shouruan.zuoye.service;

import shouruan.zuoye.domain.Comment;
import shouruan.zuoye.domain.UserCmt;

import java.util.List;

public interface CommentService {
    int insert(Comment comment);
    List<UserCmt> findByTextid(String textid);
}
