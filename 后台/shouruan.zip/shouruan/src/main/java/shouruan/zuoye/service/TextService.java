package shouruan.zuoye.service;

import shouruan.zuoye.domain.Text;

import java.util.List;

public interface TextService {
    List<Text> findByTextid(String id);
    List<Text> likeByTextContent(String content);
    List<Text> findBySortid(String sortid);
    int update(int id, String title, String content);
}
