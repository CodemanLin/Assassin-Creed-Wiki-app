package shouruan.zuoye.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import shouruan.zuoye.domain.Text;

import java.util.List;

@Repository
@Mapper
public interface TextDao {

    //    用id查询词条
    @Select("select * from text where id=#{id}")
    List<Text> findByTextid(String id);

    //     模糊查询词条
    @Select("select id,title,content from text where title like '%${content}%' or content like '%${content}%' order by time desc")
    List<Text> likeByTextContent(String content);

    //    用sortid查询词条
    @Select("select id,title,content from text where sortid=#{sortid} order by time desc")
    List<Text> findBySortid(String sortid);

    //     更新词条
    @Update("UPDATE text SET title=#{title},content=#{content} WHERE id=#{id}")
    int update(int id, String title, String content);

}
