package shouruan.zuoye.dao;
import org.apache.ibatis.annotations.Insert;
import shouruan.zuoye.domain.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface UserDao {

//    添加新账号
    @Insert("INSERT INTO user(username, password) VALUES (#{username},#{password})")
    int insert(User user);

//    用用户名查询账号
    @Select("select * from user where username=#{username}")
    List<User> findByUsername(String username);

//    查询用户名密码是否正确
    @Select("select * from user where username=#{username} and password=#{password}")
    List<User> findByUsernamePassword(User account);

}
