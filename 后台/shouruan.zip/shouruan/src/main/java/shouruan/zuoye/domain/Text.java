package shouruan.zuoye.domain;

import java.io.Serializable;

public class Text implements Serializable{
    private Integer id;
    private String title;
    private String content;
    private double time;
    private Integer sortid;

    public Text(){ }

    public Text(String title, String content, double time, Integer sortid){
        this.title = title;
        this.content = content;
        this.time = time;
        this.sortid = sortid;
    }

    public void cutContent(){
        this.content = this.content.split("\n")[0];
        this.content = this.content.split("\r")[0];
        if(this.content.length() > 50){
            this.content = this.content.substring(0,50);
        }
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSortid() {
        return sortid;
    }

    public void setSortid(Integer sortid) {
        this.sortid = sortid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
