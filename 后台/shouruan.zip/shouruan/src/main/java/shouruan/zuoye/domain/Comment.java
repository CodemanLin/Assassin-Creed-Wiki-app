package shouruan.zuoye.domain;

import java.io.Serializable;

public class Comment implements Serializable{
    private Integer id;
    private String comment;
    private double time;
    private Integer userid;
    private Integer textid;

    public Comment(){ }

    public Comment(String comment, double time, Integer userid, Integer textid){
        this.comment = comment;
        this.time = time;
        this.userid = userid;
        this.textid = textid;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getTextid() {
        return textid;
    }

    public void setTextid(Integer textid) {
        this.textid = textid;
    }
}
