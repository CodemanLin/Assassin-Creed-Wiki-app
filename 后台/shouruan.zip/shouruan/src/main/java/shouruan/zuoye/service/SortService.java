package shouruan.zuoye.service;

public interface SortService {
    int findBySort(String sort);
}
