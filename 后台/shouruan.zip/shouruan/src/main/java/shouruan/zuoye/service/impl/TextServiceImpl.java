package shouruan.zuoye.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shouruan.zuoye.dao.TextDao;
import shouruan.zuoye.domain.Text;
import shouruan.zuoye.service.TextService;

import java.util.List;

@Service("textService")
public class TextServiceImpl implements TextService {

    @Autowired
    TextDao textDao;

    @Override
    public List<Text> findByTextid(String id){
        return textDao.findByTextid(id);
    }

    @Override
    public List<Text> likeByTextContent(String content){
        return textDao.likeByTextContent(content);
    }

    @Override
    public List<Text> findBySortid(String sortid){ return textDao.findBySortid(sortid); }

    @Override
    public int update(int id, String title, String content){ return textDao.update(id,title,content);}

}
