package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.Text;
import shouruan.zuoye.service.TextService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SearchController {

    @Autowired
    TextService textService;
    Text text;

    Map<String, Object> map;

    public SearchController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/search",method= RequestMethod.GET)
    public JsonResult<Map> index(String content, Model model){
        List<Text> textList = textService.likeByTextContent(content);
        if(textList.isEmpty()){
            map.put("result","没有相关内容");
            return new JsonResult<>("400",map);
        }
        for(int i=0;i<textList.size();i++){
            textList.get(i).cutContent();
        }
        map.put("result",textList);
        return new JsonResult<>(map);
    }
}
