package shouruan.zuoye.service;

import shouruan.zuoye.domain.Tokens;

import java.util.List;

public interface TokensService {
    //    添加新token
    int insert(Tokens tokens);
    //    用userid查询账号
    boolean findByUserid(String userid);
    //    用token查询userid
    List<Tokens> findByToken(String token);
    //    删除token
    int delete(String userid);
}
