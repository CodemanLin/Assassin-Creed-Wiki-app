package shouruan.zuoye.dao;

import org.apache.ibatis.annotations.Insert;
import shouruan.zuoye.domain.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import shouruan.zuoye.domain.UserCmt;

import java.util.List;

@Repository
@Mapper
public interface CommentDao {

    //    添加评论
    @Insert("INSERT INTO comment(comment, userid, time, textid) VALUES (#{comment},#{userid},#{time},#{textid})")
    int insert(Comment comment);

    //    用词条id获得评论
    @Select("select comment,time,username from (select * from comment where textid = #{textid})a left join user on user.id = a.userid order by time")
    List<UserCmt> findByTextid(String textid);

}