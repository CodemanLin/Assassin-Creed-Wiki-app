package shouruan.zuoye.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shouruan.zuoye.dao.CommentDao;
import shouruan.zuoye.domain.Comment;
import shouruan.zuoye.domain.UserCmt;
import shouruan.zuoye.service.CommentService;

import java.util.List;

@Service("commentService")
public class CommentServiceImpl implements CommentService {
    @Autowired
    CommentDao commentDao;

    @Override
    public int insert(Comment comment){
        return commentDao.insert(comment);
    }

    @Override
    public List<UserCmt> findByTextid(String textid){
        return commentDao.findByTextid(textid);
    }

}