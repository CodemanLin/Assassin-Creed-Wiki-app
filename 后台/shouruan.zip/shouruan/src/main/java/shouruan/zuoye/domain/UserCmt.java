package shouruan.zuoye.domain;

import java.io.Serializable;

public class UserCmt implements Serializable{
    private String username;
    private String comment;
    private double time;

    public UserCmt(){ }

    public UserCmt(String username, String comment, double time){
        this.comment = comment;
        this.time = time;
        this.username = username;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
