package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.Comment;
import shouruan.zuoye.domain.Tokens;
import shouruan.zuoye.service.CommentService;
import shouruan.zuoye.service.TokensService;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CommentController {

    @Autowired
    CommentService commentService;
    @Autowired
    TokensService tokensService;
    Comment comment;
    Map<String, Object> map;

    public CommentController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/cmt",method= RequestMethod.GET)
    public JsonResult<Map> index(String token, String cmt, Integer textid, Model model){
        List<Tokens> tokensList = tokensService.findByToken(token);
        if(tokensList.isEmpty()){
            map.put("result","用户未登录");
            return new JsonResult<>("400",map);
        }
        Integer userid = tokensList.get(0).getUserid();
        double time = new Date().getTime();
        comment = new Comment(cmt,time,userid,textid);
        if(commentService.insert(comment) == 0){
            map.put("result","数据库出错");
            return new JsonResult<>("400",map);
        }
        map.put("result","评论成功");
        return new JsonResult<>(map);
    }

}
