package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.UserCmt;
import shouruan.zuoye.service.CommentService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class GetCommentController {

    @Autowired
    CommentService commentService;
    Map<String, Object> map;

    public GetCommentController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/getcmt",method= RequestMethod.GET)
    public JsonResult<Map> index(String textid, Model model){
        List<UserCmt> commentList = commentService.findByTextid(textid);
        if(commentList.isEmpty()){
            map.put("result","该词条无评论");
            return new JsonResult<>("400",map);
        }
        map.put("result",commentList);
        return new JsonResult<>(map);
    }

}
