package shouruan.zuoye.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import shouruan.zuoye.domain.Sort;

import java.util.List;

@Repository
@Mapper
public interface SortDao {

    //  用词条名查id
    @Select("select id from sort where sort=#{sort}")
    List<Sort> findBySort(String sort);

}
