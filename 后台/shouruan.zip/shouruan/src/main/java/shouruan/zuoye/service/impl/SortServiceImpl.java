package shouruan.zuoye.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shouruan.zuoye.dao.SortDao;
import shouruan.zuoye.domain.Sort;
import shouruan.zuoye.service.SortService;

import java.util.List;

@Service("sortService")
public class SortServiceImpl implements SortService {

    @Autowired
    SortDao sortDao;

    // 返回分类的id
    public int findBySort(String sort){
        List<Sort> sortList = sortDao.findBySort(sort);
        if(sortList.isEmpty()){
            return 0;
        }
        return sortList.get(0).getId();
    }

}
