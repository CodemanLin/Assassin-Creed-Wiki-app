package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.User;
import shouruan.zuoye.service.UserService;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RegisterController {

    @Autowired
    UserService userService;
    User user;
    Map<String, Object> map;

    public RegisterController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/reg",method= RequestMethod.GET)
    public JsonResult<Map> index(String username, String password, Model model){
        if(!userService.findByUsername(username).isEmpty()){
            map.put("result","用户已存在");
            return new JsonResult<>("400",map);
        }
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        user = new User(username,password);
        if(userService.insert(user) == 1){
            map.put("result","注册成功");
        }else{
            map.put("result","注册失败");
            return new JsonResult<>("400",map);
        }
        return new JsonResult<>(map);
    }
}
