package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.common.Token;
import shouruan.zuoye.domain.Tokens;
import shouruan.zuoye.domain.User;
import shouruan.zuoye.service.TokensService;
import shouruan.zuoye.service.UserService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    UserService userService;
    @Autowired
    TokensService tokensService;
    User user;
    Tokens tokens;
    Token token;
    Map<String, Object> map;

    public LoginController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/log",method= RequestMethod.GET)
    public JsonResult<Map> index(String username, String password, Model model){
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        user = new User(username,password);
        List<User> userList = userService.findByUsernamePassword(user);
        if(userList.isEmpty()){
            map.put("result","用户名或密码错误");
            return new JsonResult<>("400",map);
        }
        //查询token是否已存在
        Integer userid = userList.get(0).getId();
        if(tokensService.findByUserid(userid.toString())){
            //存在则删除
            tokensService.delete(userid.toString());
        }
        //生成toke并插入数据库
        token = new Token(username);
        tokens = new Tokens(userid,token.getToken());
        if(tokensService.insert(tokens) == 0){
            map.put("result","服务器出错");
            return new JsonResult<>("400",map);
        }
        map.put("result",token.getToken());
        return new JsonResult<>(map);
    }

}
