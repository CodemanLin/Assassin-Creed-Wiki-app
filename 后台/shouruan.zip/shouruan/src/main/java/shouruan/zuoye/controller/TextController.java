package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.Text;
import shouruan.zuoye.service.TextService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class TextController {

    @Autowired
    TextService textService;
    Text text;

    Map<String, Object> map;

    public TextController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/text",method= RequestMethod.GET)
    public JsonResult<Map> index(String id, Model model){
        List<Text> textList = textService.findByTextid(id);
        if(textList.isEmpty()){
            map.put("result","不存在该词条");
            return new JsonResult<>("400",map);
        }
        map.put("result",textList);
        return new JsonResult<>(map);
    }

}