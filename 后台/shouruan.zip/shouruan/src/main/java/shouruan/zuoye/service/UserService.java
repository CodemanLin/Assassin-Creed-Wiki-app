package shouruan.zuoye.service;

import shouruan.zuoye.domain.User;

import java.util.List;

public interface UserService {
    //    添加新账号
    int insert(User user);
    //    用用户名查询账号
    List<User> findByUsername(String username);
    //    查询用户名密码是否正确
    List<User> findByUsernamePassword(User user);
}
