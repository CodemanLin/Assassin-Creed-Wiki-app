package shouruan.zuoye.service.impl;

import shouruan.zuoye.dao.TokensDao;
import shouruan.zuoye.domain.Tokens;
import shouruan.zuoye.service.TokensService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("tokensService")
public class TokensServiceImpl implements TokensService {
    @Autowired
    TokensDao tokensDao;

    @Override
    public int insert(Tokens tokens){
        return tokensDao.insert(tokens);
    }

    @Override
    public boolean findByUserid(String userid){
        List<Tokens> tokens = tokensDao.findByUserid(userid);
        if(tokens.isEmpty()){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public List<Tokens> findByToken(String token){ return tokensDao.findByToken(token); }

    @Override
    public int delete(String userid){ return tokensDao.delete(userid); }

}