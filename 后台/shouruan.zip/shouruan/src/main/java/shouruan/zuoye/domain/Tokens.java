package shouruan.zuoye.domain;

import java.io.Serializable;

public class Tokens implements Serializable{
    private Integer userid;
    private String token;

    public Tokens(){ }

    public Tokens(Integer userid, String token){
        this.userid = userid;
        this.token = token;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

}
