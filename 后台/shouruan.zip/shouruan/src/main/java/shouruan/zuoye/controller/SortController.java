package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.Text;
import shouruan.zuoye.service.SortService;
import shouruan.zuoye.service.TextService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SortController {

    @Autowired
    SortService sortService;
    @Autowired
    TextService textService;
    Text text;

    Map<String, Object> map;

    public SortController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/sort",method= RequestMethod.GET)
    public JsonResult<Map> index(String sort, Model model){
        //获得分类id
        int id = sortService.findBySort(sort);
        if(id == 0){
            map.put("result","不存在该分类");
            return new JsonResult<>("400",map);
        }
        //获得分类词条
        List<Text> textList = textService.findBySortid(Integer.toString(id));
        if(textList.isEmpty()){
            map.put("result","该分类暂无内容");
            return new JsonResult<>("400",map);
        }
        for(int i=0;i<textList.size();i++){
            textList.get(i).cutContent();
        }
        map.put("result",textList);
        return new JsonResult<>(map);
    }

}
