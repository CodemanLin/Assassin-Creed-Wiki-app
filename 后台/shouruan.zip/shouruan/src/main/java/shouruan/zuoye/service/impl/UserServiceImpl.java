package shouruan.zuoye.service.impl;

import shouruan.zuoye.dao.UserDao;
import shouruan.zuoye.domain.User;
import shouruan.zuoye.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userService")
public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;

    @Override
    public int insert(User user){
        return userDao.insert(user);
    }

    @Override
    public List<User> findByUsername(String username){
        return userDao.findByUsername(username);
    }

    @Override
    public List<User> findByUsernamePassword(User user){
        return userDao.findByUsernamePassword(user);
    }

}