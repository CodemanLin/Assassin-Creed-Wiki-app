package shouruan.zuoye.common;

import org.springframework.util.DigestUtils;

import java.security.SecureRandom;
import java.util.Calendar;

public class Token {

    private static final Integer SALT_LENGTH = 12;
    private String token;

    public Token(){

    }

    public Token(String username){
//        生成随机数
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);

        Long time = Calendar.getInstance().getTimeInMillis();
        String hash = salt+username+time;
        token = DigestUtils.md5DigestAsHex(hash.getBytes());
    }

    public String getToken(){
        return token;
    }

}
