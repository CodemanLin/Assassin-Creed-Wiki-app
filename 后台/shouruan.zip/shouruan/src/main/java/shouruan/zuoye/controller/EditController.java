package shouruan.zuoye.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import shouruan.zuoye.common.JsonResult;
import shouruan.zuoye.domain.Comment;
import shouruan.zuoye.domain.Tokens;
import shouruan.zuoye.service.TextService;
import shouruan.zuoye.service.TokensService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class EditController {

    @Autowired
    TextService textService;
    @Autowired
    TokensService tokensService;
    Comment comment;
    Map<String, Object> map;

    public EditController(){
        map = new HashMap<String, Object>();
    }

    @RequestMapping(value="/edit",method= RequestMethod.POST)
    public JsonResult<Map> index(String token, String title, String content, Integer textid, Model model){
        List<Tokens> tokensList = tokensService.findByToken(token);
        if(tokensList.isEmpty()){
            map.put("result","用户未登录");
            return new JsonResult<>("400",map);
        }

        if(textService.update(textid,title,content) == 0){
            map.put("result","数据库出错");
            return new JsonResult<>("400",map);
        }
        map.put("result","编辑成功");
        return new JsonResult<>(map);
    }

}
