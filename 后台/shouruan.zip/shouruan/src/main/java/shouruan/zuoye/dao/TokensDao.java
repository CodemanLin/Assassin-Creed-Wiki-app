package shouruan.zuoye.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import shouruan.zuoye.domain.Tokens;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface TokensDao {

    //    添加新账号
    @Insert("INSERT INTO tokens(userid, token) VALUES (#{userid},#{token})")
    int insert(Tokens tokens);

    //    用userid查询token
    @Select("select * from tokens where userid=#{userid}")
    List<Tokens> findByUserid(String userid);

    //    用token查询userid
    @Select("select * from tokens where token=#{token}")
    List<Tokens> findByToken(String token);

    //删除token
    @Delete("delete from tokens where userid=#{userid}")
    int delete(String userid);

}